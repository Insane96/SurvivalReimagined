tag @s add withering
